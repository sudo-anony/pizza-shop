<?php

namespace App\Models;

class Orderitems extends Posts
{
    protected $table = 'order_has_items';
}
