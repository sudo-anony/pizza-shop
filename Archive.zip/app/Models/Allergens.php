<?php

namespace App\Models;

class Allergens extends Posts
{
}
