<?php

namespace App\Models;

use App\User as ParentUser;

class User extends ParentUser
{
    protected $modelName = \App\User::class;
}
