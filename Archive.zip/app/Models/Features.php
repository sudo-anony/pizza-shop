<?php

namespace App\Models;

class Features extends Posts
{
}
