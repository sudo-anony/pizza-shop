<?php

namespace App\Models;

class Drivercategories extends Posts
{
}
