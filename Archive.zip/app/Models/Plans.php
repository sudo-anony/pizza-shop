<?php

namespace App\Models;

use App\Plans as ParentPlans;

class Plans extends ParentPlans
{
    protected $modelName = \App\Plans::class;
}
