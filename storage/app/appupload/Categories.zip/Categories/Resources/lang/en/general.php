<?php

return [

    'name'              => 'Categories',
    'description'       => 'This is my awesome module',

];