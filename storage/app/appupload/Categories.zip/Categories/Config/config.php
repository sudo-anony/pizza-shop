<?php

return [
    'name' => 'Categories'
];
